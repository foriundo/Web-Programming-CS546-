export const mongoConfig = {
  serverUrl: 'mongodb://localhost:27017/',
  database: 'Fernando_Oriundo_lab4'
};
